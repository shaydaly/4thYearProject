#config file containing credentials for rds mysql instance
db_username = "'shayAWS'"
db_password = "'ShayVisCar'"
db_name = "'CARVIS_DB'"
rds_host  = "'carvis-pgres-db-backup.cuqx5uhbzyug.us-east-1.rds.amazonaws.com'"