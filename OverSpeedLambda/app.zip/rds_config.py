#config file containing credentials for rds mysql instance
db_username = "shayawsdb"
db_password = "awsdbinstance"
db_name = "carvisDB"